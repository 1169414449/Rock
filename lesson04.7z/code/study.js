// 引用类型与值类型
// let obj = {};
// let obj2 = {};
// let obj3 = obj;
// console.log(obj === obj2);// false
// console.log(obj === obj3);// true

// function fn(){
// 	return {
//
// 	}
// }
// const obj = fn();
// const obj2 = fn();
// console.log(obj === obj2);// false

// let obj = {};
// function fn(){
// 	return obj;
// }
// const obj2 = fn();
// const obj3 = fn();
// console.log(obj2 === obj3);
// obj.a = 100;
// console.log(obj2,obj3);
// 金庸-->鹿鼎记-->韦小宝-->七个
