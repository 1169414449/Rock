const template = (`
	<div class="page">
	    <a href="javascript:;" class="active">1</a>
	    <a href="javascript:;">2</a>
	    <a href="javascript:;">3</a>
	</div>
`)
export default {
	template
}