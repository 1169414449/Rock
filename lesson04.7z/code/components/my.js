let template = "abc";
export default {
	template
}