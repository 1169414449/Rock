let str = "!!";
// abcabcab!!
console.log(str.padStart(10,"abc"))
// !!abcabcab
console.log(str.padEnd(10,"abc"))