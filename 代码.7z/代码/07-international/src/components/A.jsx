import React, { useEffect } from 'react'

export default function A() {
    useEffect(()=>{
        console.log('A come');
        return ()=>{
            console.log('A die');
        }
    },[])
    return (
        <div>A</div>
    )
}
