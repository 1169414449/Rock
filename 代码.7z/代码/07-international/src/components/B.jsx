import React, { useEffect } from 'react'

export default function B() {
    useEffect(() => {
        console.log('B come');
        return () => {
            console.log('B die');
        }
    }, [])
    return (
        <div>B</div>
    )
}
