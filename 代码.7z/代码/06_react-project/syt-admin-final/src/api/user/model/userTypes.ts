export type LoginResponse = string

export interface GetUserInfoResponse {
  name: string;
  avatar: string;
}
