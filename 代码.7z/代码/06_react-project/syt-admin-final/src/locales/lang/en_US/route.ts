const route = {
  dashboard: "Dashboard",
  hospital: "Hospital",
  hospitalSet: "Hospital Set",
  hospitalList: "Hospital List",
  data: "Data",
  dict: "Data Dict",
  member: "Member",
  memberList: "Member List",
  certificationList: "Certification List",
  order: "Order",
  orderList: "Order List",
  statistics: "Statistics",
  statisticsList: "Statistics List",
};

export default route;
