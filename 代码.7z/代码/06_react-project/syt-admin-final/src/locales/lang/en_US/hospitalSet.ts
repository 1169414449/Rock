const hospitalSet = {
  hosname: "Hosname",
  hoscode: "Hoscode",
  searchBtnText: "Search",
  resetBtnText: "Reset",
  addBtnText: "Add",
  batchRemoveBtnText: "Batch Remove",
  updateBtnText: "Update Hospital",
  removeBtnText: "Remove Hospital",
  index: "Index",
  apiUrl: "Api Url",
  signKey: "Signature",
  contactsName: "Contacts Name",
  contactsPhone: "Contacts Phone",
  operator: "Operator",
  total: 'Total: '
};

export default hospitalSet;
