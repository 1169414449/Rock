const app = {
  dashboard: "Dashboard",
  title: "SYT Admin",
};

export default app;
