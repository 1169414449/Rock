const route = {
  dashboard: "首页",
  hospital: "医院管理",
  hospitalSet: "医院设置",
  hospitalList: "医院列表",
  data: "数据管理",
  dict: "数据字典",
  member: "会员管理",
  memberList: "会员列表",
  certificationList: "认证审批列表",
  order: "订单管理",
  orderList: "订单列表",
  statistics: "统计管理",
  statisticsList: "统计列表",
};

export default route;
