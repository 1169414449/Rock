const app = {
  dashboard: "首页",
  title: "商医通管理系统",
};

export default app;
