# 仓库说明
- syt-admin_base 尚医通后台(中台)管理项目 基础版
- syt-admin_final 尚医通后台(中台)管理项目 完成版
- syt-admin_docs 尚医通后台(中台)管理项目 文档