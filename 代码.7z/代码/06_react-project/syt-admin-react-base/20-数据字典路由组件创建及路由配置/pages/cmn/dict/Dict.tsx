import { Card, Table } from 'antd'
import { ColumnsType } from 'antd/lib/table'
import React from 'react'

export default function Dict() {
    const columns:ColumnsType<any> = [
        {
            title:'名称'
        },
        {
            title:'编码'
        },
        {
            title:'值'
        },
        {
            title:'创建时间'
        }
    ]
    return (
        <Card>
            <Table
                columns={columns}
                pagination={false}
            />
        </Card>
    )
}
