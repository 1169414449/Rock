/**
 * 医院设置相关api函数
 */
import {request} from '@utils/http'
import { IHospitalSetData, IHospitalSetListResponse, IHospitalSetUpdateData } from './model/hospitalSetTypes'
/**
 * 
 * @param page 当前页 必填
 * @param limit 每页几条 必填
 * @param hosname 医院名称
 * @param hoscode 医院编号
 * @returns 
 */
export const getHospitalSetList = (page:number,limit:number,hosname?:string,hoscode?:string)=>{
    return request.get<any, IHospitalSetListResponse>(`/admin/hosp/hospitalSet/${page}/${limit}`, {
        params:{
            hosname,
            hoscode
        }
    })
}
/**
 * 添加医院设置
 * @param data 请求体数据
 * @returns null
 */
export const addHospitalSet = (data:IHospitalSetData)=>{
    return request.post<any,null>('/admin/hosp/hospitalSet/save', data)
}

/**
 * 根据id 删除医院设置
 * @param id 
 * @returns null
 */
export const deleteHospitalSetById = (id:string)=>{
    return request.delete<any,null>(`/admin/hosp/hospitalSet/remove/${id}`)
}
/**
 * 根据 数组id列表，进行批量删除
 * @param ids id 的数组
 * @returns null
 */
export const removeBatch = (ids:React.Key[])=>{
    return request.delete<any,null>('/admin/hosp/hospitalSet/batchRemove',{
        data:ids
    })
}
/**
 * 根据id获取医院设置数据
 * @param id 
 * @returns Promise<IHospitalSetData>
 */
export const getHospitalSetById = (id:string)=>{
    return request.get<any,IHospitalSetData>('/admin/hosp/hospitalSet/get/' + id)
}
/**
 * 更新医院设置
 * @param data 
 * @returns null
 */
export const updateHospitalSet = (data:IHospitalSetUpdateData)=>{
    return request.put<any,null>('/admin/hosp/hospitalSet/update', data)
}