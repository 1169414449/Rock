import React,{useState} from 'react'
import Anthor from './components/Anthor'
import AxiosTable from './components/AxiosTable'
import AxiosTest from './components/AxiosTest'
import ButtonTest from './components/ButtonTest'
import FormData from './components/FormData'
import FormTest from './components/FormTest'
import PageTest from './components/PageTest'
import TableTest from './components/TableTest'

export default function App() {
    return (
        <div>
            {/* <ButtonTest/> */}
            {/* <TableTest/> */}
            {/* <PageTest/> */}
            {/* <AxiosTest/> */}
            {/* <AxiosTable/> */}
            {/* <FormTest/> */}
            {/* <FormData/> */}
            <Anthor/>
        </div>
    )
}
