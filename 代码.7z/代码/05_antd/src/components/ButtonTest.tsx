import React, { useState } from 'react'
import { Button } from 'antd'
import { SearchOutlined, QuestionCircleOutlined } from '@ant-design/icons';
export default function ButtonTest() {
    let [loading, setLoading] = useState(false);
    return (
        <>
            <h3>Button按钮</h3>
            <Button type='primary'>按钮</Button>
            <Button type="primary" icon={<SearchOutlined />} block >
                Search
            </Button>
            <Button danger type='primary'>danger</Button>
            <Button type='primary' disabled>disabled</Button>
            <Button href='http://baidu.com'>百度</Button>
            <Button htmlType='submit' icon={<QuestionCircleOutlined />}>htmlType</Button>


            <button type='submit'>提交</button>

            <QuestionCircleOutlined />

            <Button loading={loading}>loading</Button>
            <Button onClick={() => {
                setLoading(!loading)
            }}> changeLoading</Button>

            <Button shape='circle' icon={<SearchOutlined />}></Button>
        </>
    )
}
