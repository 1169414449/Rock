import React, { useEffect, useState } from 'react'
import { getUsers } from '../api/github';
import { IUserList } from '../api/model/githubTypes';

export default function AxiosTest() {
    let [users, setUsers] = useState<IUserList>([])

    useEffect(()=>{
        async function main(){
            let res = await getUsers('aa')
            console.log('res: ', res);
            console.log('user: ', res.items);// ts 报错，res身上没有 items属性
            // ts 是在编译阶段执行代码检查，数据是执行之后才有数据结构，需要让ts直到未来请求回来的数据结构，也就是需要先定义出响应数据的类型告诉ts
            setUsers(res.items);
        }
        main();
    }, [])
    return (
        <div>
            <h3>Axios 测试</h3>
        </div>
    )
}
