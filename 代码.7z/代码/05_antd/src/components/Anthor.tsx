import { Button, Card, message, Space,Modal } from 'antd'
import {ExclamationCircleFilled} from '@ant-design/icons'
import React from 'react'

const {confirm} = Modal
export default function Anthor() {
    return (
        <div style={{ background: 'skyblue' }}>
            <h3>Space组件</h3>
            <div>
                <Space size={50}>
                    <Button>保存</Button>
                    <Button>取消</Button>
                </Space>
            </div>
            <h3>Card组件</h3>
            <Card>
                <p>我是card组件中的内容</p>
            </Card>
            <h3>message函数 - 提示信息</h3>
            <Button onClick={() => {
                message.success('添加成功!')
            }}>成功提示</Button>
            <Button onClick={() => {
                message.error('添加失败')
            }}>失败提示</Button>

            <h3>Confirm 提示框</h3>
            <Button onClick={() => {
                confirm({
                    title: '确定删除么?',
                    icon: <ExclamationCircleFilled />,
                    content: '删除当前记录',
                    onOk() {
                        console.log('OK');
                    },
                    onCancel() {
                        console.log('Cancel');
                    },
                });
            }}>删除</Button>
        </div>
    )
}
