import { Component } from 'react'
// 定义类组件，组件名要与文件名一致
class HeaderClass extends Component {
    render(){
        return (
            <div>HeaderClass组件</div>
        )
    }
}
// 默认暴露该组件
export default HeaderClass