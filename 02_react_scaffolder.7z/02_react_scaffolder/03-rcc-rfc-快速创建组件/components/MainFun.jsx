function MainFun(){
    return (
        <div>MainFun</div>
    )
}

export default MainFun;