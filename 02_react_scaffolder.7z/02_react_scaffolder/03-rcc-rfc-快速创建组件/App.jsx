import Footer from './components/Footer';
import HeaderClass from './components/HeaderClass'
import MainFun from './components/MainFun';
function App() {
    return (
        <div>
            <HeaderClass/>
            <MainFun />
            <Footer/>
        </div>
    );
}
export default App;
