import React from 'react'

export default function TestState({count,msg}) {
    
    return (
        <div>
            <h3>Son</h3>
            <p>props count: {count}</p>
            <p>props msg: {msg}</p>
        </div>
    )
}
