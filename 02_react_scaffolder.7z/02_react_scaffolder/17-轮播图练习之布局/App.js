import React, { Component } from 'react'
import Swipper from './components/Swipper/Swipper'

export default class App extends Component {
    render() {
        return (
            <div>
                <Swipper/>
            </div>
        )
    }
}
