import React from 'react'

export default function Main() {
    return (
        <div className="row">
            <div className="card">
                <a href="https://github.com/reactjs" target="_blank" rel="noreferrer">
                    <img src="https://avatars.githubusercontent.com/u/6412038?v=3" alt="" style={{ width: 100 }} />
                </a>
                <p className="card-text">reactjs</p>
            </div>
            <div className="card">
                <a href="https://github.com/reactjs" target="_blank" rel="noreferrer">
                    <img src="https://avatars.githubusercontent.com/u/6412038?v=3" alt="" style={{ width: 100 }} />
                </a>
                <p className="card-text">reactjs</p>
            </div>
            <div className="card">
                <a href="https://github.com/reactjs" target="_blank" rel="noreferrer">
                    <img src="https://avatars.githubusercontent.com/u/6412038?v=3" alt="" style={{ width: 100 }} />
                </a>
                <p className="card-text">reactjs</p>
            </div>
            <div className="card">
                <a href="https://github.com/reactjs" target="_blank" rel="noreferrer">
                    <img src="https://avatars.githubusercontent.com/u/6412038?v=3" alt="" style={{ width: 100 }} />
                </a>
                <p className="card-text">reactjs</p>
            </div>
            <div className="card">
                <a href="https://github.com/reactjs" target="_blank" rel="noreferrer">
                    <img src="https://avatars.githubusercontent.com/u/6412038?v=3" alt="" style={{ width: 100 }} />
                </a>
                <p className="card-text">reactjs</p>
            </div>
        </div>
    )
}
