import React from 'react'
import TodoList from './components/TodoList/TodoList'
// 导入App根组件样式
import './App.css'
export default function App() {
    return (
        <div>
            <TodoList />
        </div>
    )
}
