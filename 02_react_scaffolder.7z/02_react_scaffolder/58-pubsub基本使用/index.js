import React from 'react';
import ReactDOM from 'react-dom/client';
// 导入App根组件
import App from './App';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <App />
);
