import React from 'react'
import Son2 from './Son2'

export default function Father2() {
  return (
    <div>
        <h3>Father2</h3>
        <Son2/>
    </div>
  )
}
