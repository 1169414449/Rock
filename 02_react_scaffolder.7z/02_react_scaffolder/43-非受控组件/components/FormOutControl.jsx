import React from 'react'

export default function FormOutControl() {
  return (
    <div>FormOutControl</div>
  )
}
