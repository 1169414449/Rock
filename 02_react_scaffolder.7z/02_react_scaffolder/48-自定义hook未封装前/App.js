import React from 'react'
import FuMing from './components/FuMing'
import Lili from './components/Lili'

export default function App() {
    return (
        <div>
            <Lili/>
            <FuMing/>
        </div>
    )
}
