import React, { Component } from 'react'
import styles from './index.module.css'
export default class A extends Component {
  render() {
    return (
      <div className={styles.box}>A</div>
    )
  }
}
