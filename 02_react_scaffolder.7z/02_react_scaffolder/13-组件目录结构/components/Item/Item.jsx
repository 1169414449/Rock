import React, { Component } from 'react'
import './index.css'
export default class Item extends Component {
    render() {
        return (
            <div>Item</div>
        )
    }
}
