import React from 'react'
import './index.css'
export default function Footer() {
  return (
    <div>Footer</div>
  )
}
