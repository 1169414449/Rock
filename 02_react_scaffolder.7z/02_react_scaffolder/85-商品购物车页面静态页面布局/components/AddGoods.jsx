import React from 'react'

export default function AddGoods() {
    return (
        <>
            <h3>添加商品</h3>
            <form>
                <p>商品名称：<input type="text" name="" id="" /></p>
                <p>商品价格：<input type="text" name="" id="" /></p>
                <p><button>添加商品</button></p>
            </form>
        </>

    )
}
