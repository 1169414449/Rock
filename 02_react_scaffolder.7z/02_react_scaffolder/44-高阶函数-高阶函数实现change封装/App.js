import React from 'react'
import FormControl from './components/FormControl'

export default function App() {
  return (
    <div>
        <FormControl/>
    </div>
  )
}
