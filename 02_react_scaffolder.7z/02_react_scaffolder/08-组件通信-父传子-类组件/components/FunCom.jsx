import React from 'react'

export default function FunCom() {
    console.log('FunCom run');
    return (
        <div>FunCom</div>
    )
}
