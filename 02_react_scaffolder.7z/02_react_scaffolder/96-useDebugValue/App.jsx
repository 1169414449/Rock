import React from 'react'
import useFriendStatus from './hook/useFriendStatus'

export default function App() {
    useFriendStatus()
    return (
        <div>App</div>
    )
}
