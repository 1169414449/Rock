import React, { Component } from 'react'

export default class ClassTest extends Component {
    state = {
        count:101
    }
    render() {
        return (
            <div>ClassTest</div>
        )
    }
}
