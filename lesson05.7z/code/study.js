// function Vue(){
//
// }
// const obj = new Vue();
// const obj2 = new Vue()

const obj = {
	pageNo:1
}
let pageNo = 100;
const {pageNo} = obj;
