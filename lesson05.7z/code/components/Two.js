export default {
	template:(`
		<div>
			<h3>two</h3>
		</div>
	`)
}