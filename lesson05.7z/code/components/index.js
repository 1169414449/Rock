import One from "./One.js";
import Two from "./Two.js";
// 暴露出去的是一个对象，对象中的属性即是全局组件的配置信息，属性的名字即是组件的名字。
export default {
	One,
	Two
}

